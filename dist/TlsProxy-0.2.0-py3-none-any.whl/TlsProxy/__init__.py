#! python3

def nop(*args, **kwargs):
    pass