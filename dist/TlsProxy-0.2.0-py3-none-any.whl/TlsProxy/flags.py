#! python3
''' this module provide standard usage of TLS-Proxy '''

import sys

def nop(*args, **kwargs):
    pass

if __name__ == '__main__':
    pass